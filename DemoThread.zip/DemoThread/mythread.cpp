#include "mythread.h"
#include <QThread>

MyThread::MyThread():
{

}
